#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <limits>
using namespace std;

struct Transaction {
    string type;
    double amount;
    string details;
};

class Account {
private:
    int accountNumber;
    double balance;
    vector<Transaction> history;

public:
    Account(int number, double openingBalance = 0.0)
        : accountNumber(number), balance(openingBalance) {}

    int getAccountNumber() const { return accountNumber; }
    double getBalance() const { return balance; }

    void addTransaction(const string& type, double amount, const string& details) {
        history.push_back({type, amount, details});
    }

    bool deposit(double amount) {
        if (amount <= 0) return false;
        balance += amount;
        addTransaction("Deposit", amount, "Money added to account");
        return true;
    }

    bool withdraw(double amount) {
        if (amount <= 0 || amount > balance) return false;
        balance -= amount;
        addTransaction("Withdrawal", amount, "Money withdrawn from account");
        return true;
    }

    void showTransactions() const {
        cout << "\nTransaction history for account " << accountNumber << ":\n";
        if (history.empty()) {
            cout << "No transactions yet.\n";
            return;
        }
        for (size_t i = 0; i < history.size(); i++) {
            cout << i + 1 << ". " << history[i].type
                 << " | Amount: Rs. " << fixed << setprecision(2) << history[i].amount
                 << " | " << history[i].details << '\n';
        }
    }
};

class Customer {
private:
    int customerId;
    string name;
    Account account;

public:
    Customer(int id, const string& customerName, int accountNumber, double openingBalance)
        : customerId(id), name(customerName), account(accountNumber, openingBalance) {
        if (openingBalance > 0) account.addTransaction("Opening Balance", openingBalance, "Account created");
    }

    int getCustomerId() const { return customerId; }
    string getName() const { return name; }
    Account& getAccount() { return account; }
    const Account& getAccount() const { return account; }

    void display() const {
        cout << "Customer ID: " << customerId
             << " | Name: " << name
             << " | Account No: " << account.getAccountNumber()
             << " | Balance: Rs. " << fixed << setprecision(2)
             << account.getBalance() << '\n';
    }
};

class BankingSystem {
private:
    vector<Customer> customers;
    int nextCustomerId = 1001;
    int nextAccountNumber = 5001;

    int findCustomerIndex(int customerId) const {
        for (size_t i = 0; i < customers.size(); i++)
            if (customers[i].getCustomerId() == customerId) return static_cast<int>(i);
        return -1;
    }

    int findAccountIndex(int accountNumber) const {
        for (size_t i = 0; i < customers.size(); i++)
            if (customers[i].getAccount().getAccountNumber() == accountNumber)
                return static_cast<int>(i);
        return -1;
    }

public:
    void createCustomer() {
        string name;
        double openingBalance;
        cout << "Enter customer name: ";
        getline(cin >> ws, name);
        cout << "Enter opening balance (Rs.): ";
        if (!(cin >> openingBalance) || openingBalance < 0) {
            cout << "Invalid balance.\n";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            return;
        }
        customers.emplace_back(nextCustomerId++, name, nextAccountNumber++, openingBalance);
        cout << "Customer created successfully.\n";
        customers.back().display();
    }

    void depositMoney() {
        int accountNumber;
        double amount;
        cout << "Enter account number: ";
        cin >> accountNumber;
        int index = findAccountIndex(accountNumber);
        if (index == -1) { cout << "Account not found.\n"; return; }
        cout << "Enter deposit amount: ";
        cin >> amount;
        if (customers[index].getAccount().deposit(amount))
            cout << "Deposit successful. New balance: Rs. " << customers[index].getAccount().getBalance() << '\n';
        else cout << "Invalid amount. Deposit must be greater than zero.\n";
    }

    void withdrawMoney() {
        int accountNumber;
        double amount;
        cout << "Enter account number: ";
        cin >> accountNumber;
        int index = findAccountIndex(accountNumber);
        if (index == -1) { cout << "Account not found.\n"; return; }
        cout << "Enter withdrawal amount: ";
        cin >> amount;
        if (customers[index].getAccount().withdraw(amount))
            cout << "Withdrawal successful. New balance: Rs. " << customers[index].getAccount().getBalance() << '\n';
        else cout << "Withdrawal failed. Check amount and available balance.\n";
    }

    void transferMoney() {
        int fromAccount, toAccount;
        double amount;
        cout << "Enter sender account number: ";
        cin >> fromAccount;
        cout << "Enter receiver account number: ";
        cin >> toAccount;

        int fromIndex = findAccountIndex(fromAccount);
        int toIndex = findAccountIndex(toAccount);
        if (fromIndex == -1 || toIndex == -1) { cout << "Sender or receiver account not found.\n"; return; }
        if (fromIndex == toIndex) { cout << "Cannot transfer to the same account.\n"; return; }

        cout << "Enter transfer amount: ";
        cin >> amount;
        if (amount <= 0 || amount > customers[fromIndex].getAccount().getBalance()) {
            cout << "Transfer failed. Check amount and available balance.\n";
            return;
        }

        customers[fromIndex].getAccount().withdraw(amount);
        customers[fromIndex].getAccount().addTransaction("Transfer Out", amount, "Transferred to account " + to_string(toAccount));
        customers[toIndex].getAccount().deposit(amount);
        customers[toIndex].getAccount().addTransaction("Transfer In", amount, "Received from account " + to_string(fromAccount));
        cout << "Transfer successful.\n";
    }

    void showAllCustomers() const {
        if (customers.empty()) { cout << "No customers available.\n"; return; }
        cout << "\n--- Customer List ---\n";
        for (const Customer& customer : customers) customer.display();
    }

    void showAccountDetails() const {
        int accountNumber;
        cout << "Enter account number: ";
        cin >> accountNumber;
        int index = findAccountIndex(accountNumber);
        if (index == -1) { cout << "Account not found.\n"; return; }
        customers[index].display();
        customers[index].getAccount().showTransactions();
    }

    void run() {
        int choice;
        do {
            cout << "\n===== CodeAlpha Task 4: Banking System =====\n"
                 << "1. Create customer/account\n"
                 << "2. Deposit money\n"
                 << "3. Withdraw money\n"
                 << "4. Transfer funds\n"
                 << "5. View all customers\n"
                 << "6. View account and transaction details\n"
                 << "0. Exit\n"
                 << "Enter choice: ";
            if (!(cin >> choice)) {
                cout << "Invalid input. Exiting.\n";
                break;
            }
            switch (choice) {
                case 1: createCustomer(); break;
                case 2: depositMoney(); break;
                case 3: withdrawMoney(); break;
                case 4: transferMoney(); break;
                case 5: showAllCustomers(); break;
                case 6: showAccountDetails(); break;
                case 0: cout << "Thank you for using the banking system.\n"; break;
                default: cout << "Invalid choice. Try again.\n";
            }
        } while (choice != 0);
    }
};

int main() {
    BankingSystem bank;
    bank.run();
    return 0;
}
