# Task 4: Banking System

- Uses `Customer`, `Account`, and `Transaction` structures/classes.
- Supports account creation, deposits, withdrawals, transfers, customer list, and transaction history.
- Run: compile `banking_system.cpp` and execute the program.

## Compile using g++
```bash
g++ sudoku_solver.cpp -o sudoku_solver
./sudoku_solver

g++ banking_system.cpp -o banking_system
./banking_system
```
On Windows, run the resulting `.exe` file instead of `./...`.

Note: This is an educational console project. It does not store data permanently and is not intended for real banking.
