# CodeAlpha C++ Internship Projects

This folder contains two beginner-friendly console-based C++ projects.

## Task 3 — Sudoku Solver
- Represents the Sudoku puzzle as a 9x9 two-dimensional array.
- Uses backtracking to try valid numbers.
- Checks row, column, and 3x3 box constraints.
- Run: compile `sudoku_solver.cpp` and execute the program.

## Task 4 — Banking System
- Uses `Customer`, `Account`, and `Transaction` structures/classes.
- Supports account creation, deposits, withdrawals, transfers, customer list, and transaction history.
- Run: compile `banking_system.cpp` and execute the program.

## Compile using g++
```bash
g++ sudoku_solver.cpp -o sudoku_solver
./sudoku_solver

g++ banking_system.cpp -o banking_system
./banking_system
```
On Windows, run the resulting `.exe` file instead of `./...`.

Note: This is an educational console project. It does not store data permanently and is not intended for real banking.
