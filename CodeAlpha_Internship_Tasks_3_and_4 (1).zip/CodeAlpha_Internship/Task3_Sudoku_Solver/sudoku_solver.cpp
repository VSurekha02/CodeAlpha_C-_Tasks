#include <iostream>
using namespace std;

const int SIZE = 9;

void printBoard(int board[SIZE][SIZE]) {
    for (int row = 0; row < SIZE; row++) {
        if (row % 3 == 0 && row != 0) cout << "------+-------+------\n";
        for (int col = 0; col < SIZE; col++) {
            if (col % 3 == 0 && col != 0) cout << "| ";
            if (board[row][col] == 0) cout << ". ";
            else cout << board[row][col] << " ";
        }
        cout << '\n';
    }
}

bool isSafe(int board[SIZE][SIZE], int row, int col, int number) {
    for (int i = 0; i < SIZE; i++) {
        if (board[row][i] == number) return false;
        if (board[i][col] == number) return false;
    }

    int startRow = row - row % 3;
    int startCol = col - col % 3;
    for (int r = startRow; r < startRow + 3; r++) {
        for (int c = startCol; c < startCol + 3; c++) {
            if (board[r][c] == number) return false;
        }
    }
    return true;
}

bool solveSudoku(int board[SIZE][SIZE]) {
    for (int row = 0; row < SIZE; row++) {
        for (int col = 0; col < SIZE; col++) {
            if (board[row][col] == 0) {
                for (int number = 1; number <= 9; number++) {
                    if (isSafe(board, row, col, number)) {
                        board[row][col] = number;
                        if (solveSudoku(board)) return true;
                        board[row][col] = 0; // Backtrack
                    }
                }
                return false;
            }
        }
    }
    return true; // No empty cells remain
}

int main() {
    int board[SIZE][SIZE] = {
        {5, 3, 0, 0, 7, 0, 0, 0, 0},
        {6, 0, 0, 1, 9, 5, 0, 0, 0},
        {0, 9, 8, 0, 0, 0, 0, 6, 0},
        {8, 0, 0, 0, 6, 0, 0, 0, 3},
        {4, 0, 0, 8, 0, 3, 0, 0, 1},
        {7, 0, 0, 0, 2, 0, 0, 0, 6},
        {0, 6, 0, 0, 0, 0, 2, 8, 0},
        {0, 0, 0, 4, 1, 9, 0, 0, 5},
        {0, 0, 0, 0, 8, 0, 0, 7, 9}
    };

    cout << "CodeAlpha Task 3: Sudoku Solver\n\n";
    cout << "Puzzle (0 means empty):\n";
    printBoard(board);

    if (solveSudoku(board)) {
        cout << "\nSolved Sudoku:\n";
        printBoard(board);
    } else {
        cout << "\nNo solution exists for this puzzle.\n";
    }
    return 0;
}
