# Task 3: Sudoku Solver

## Task 3 — Sudoku Solver
- Represents the Sudoku puzzle as a 9x9 two-dimensional array.
- Uses backtracking to try valid numbers.
- Checks row, column, and 3x3 box constraints.
- Run: compile `sudoku_solver.cpp` and execute the program.

